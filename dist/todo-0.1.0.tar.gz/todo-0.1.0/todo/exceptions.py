class ServiceUnavailableError(Exception):
    pass


class BusinessError(Exception):
    pass
